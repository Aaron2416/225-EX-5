package com.example.dicegamev1;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private Button rollButton;
    private Button resetButton;
    private TextView resultTextView;
    private TextView scoreTextView;
    private ImageView diceImageView1, diceImageView2;
    private int[] diceImages = { R.drawable.dice1, R.drawable.dice2, R.drawable.dice3,
            R.drawable.dice4, R.drawable.dice5, R.drawable.dice6 };
    private int player1Score = 0;
    private int player2Score = 0;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // linking views from XML layout to Java code
        rollButton = findViewById(R.id.roll_button);
        resetButton = findViewById(R.id.reset_button);
        resultTextView = findViewById(R.id.result_text_view);
        scoreTextView = findViewById(R.id.score_text_view);
        diceImageView1 = findViewById(R.id.dice_image_view_1);
        diceImageView2 = findViewById(R.id.dice_image_view_2);

        // setting up the onClickListener for the rollButton
        rollButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // generate two random numbers between 0 and 5
                int diceRoll1 = new Random().nextInt(6);
                int diceRoll2 = new Random().nextInt(6);

                // determine winner or draw
                String result;
                if (diceRoll1 > diceRoll2) {
                    result = "WINNER : Player 1";
                    player1Score++;
                } else if (diceRoll2 > diceRoll1) {
                    result = "WINNER : Player 2";
                    player2Score++;
                } else {
                    result = "RESULT : Draw";
                }
                resultTextView.setText(result);

                // set the dice images using the random numbers
                diceImageView1.setImageResource(diceImages[diceRoll1]);
                diceImageView2.setImageResource(diceImages[diceRoll2]);

                // update the score text view
                String score = "Player 1: " + player1Score + " - Player 2: " + player2Score;
                scoreTextView.setText(score);
            }
        });

        // setting up the onClickListener for the resetButton
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                player1Score = 0;
                player2Score = 0;
                resultTextView.setText("");
                scoreTextView.setText("");
                diceImageView1.setImageResource(R.drawable.dice1);
                diceImageView2.setImageResource(R.drawable.dice1);
            }
        });
    }
}
