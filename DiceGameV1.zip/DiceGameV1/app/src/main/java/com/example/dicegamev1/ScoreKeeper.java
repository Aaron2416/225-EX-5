package com.example.dicegamev1;

public class ScoreKeeper {

    private int player1Score;
    private int player2Score;

    public ScoreKeeper() {
        this.player1Score = 0;
        this.player2Score = 0;
    }

    public void updateScore(int diceRoll1, int diceRoll2) {
        if (diceRoll1 > diceRoll2) {
            player1Score++;
        } else if (diceRoll2 > diceRoll1) {
            player2Score++;
        }
    }

    public void resetScore() {
        player1Score = 0;
        player2Score = 0;
    }

    public int getPlayer1Score() {
        return player1Score;
    }

    public int getPlayer2Score() {
        return player2Score;
    }
}
